"Manual_matrixconverter_17Sept2014.pdf" is a manual that gives detailed instructions describing how to run MatrixConverter.  

The Cycadtest.txt file is a tab delimited file that contains 50 morphological characters and 300 species of Cycads.  Characters and character states were obtained by parsing the taxonomic descriptions of the Cycads (taken from the Cycad Pages website) using CharaParser and aligned using MatrixGenerator.  This dataset contains  discrete, continuous, and non-homologous characters states that are intended to show the user the functionality of MatrixConverter.  
